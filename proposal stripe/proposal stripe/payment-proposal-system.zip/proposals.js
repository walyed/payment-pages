// proposals.js
// Тут ти просто додаєш/міняєш пропозали під клієнтів

module.exports = [
  {
    id: "ivan-001",
    clientName: "Іван",
    title: "Підтримка сайту (1 місяць, без продовження)",
    description:
      "Щомісячна підтримка сайту протягом 1 місяця: дрібні правки, консультації, моніторинг.",
    // Скільки ти хочеш ОТРИМАТИ ЧИСТИМИ (без комісії), в ЦЕНТАХ:
    amountNet: 1000, // 200.00 USD
    currency: "usd",

    // логіка білінгу:
    recurring: false,        // так, це підписка (щоб працював trial і автосписання)
    interval: "month",      // інтервал підписки
    cancellationMonths: 1,  // 👈 1 місяць і ВСЕ (далі відрубаємо через webhook)
    trialDays: 1            // 👈 перший платіж через 1 день
  },

  {
    id: "olya-002",
    clientName: "Оля",
    title: "Підтримка сайту (довгострокова)",
    description:
      "Щомісячна підтримка сайту без фіксованого кінця. Автоматичні списання щомісяця.",
    amountNet: 500, // 50.00 USD
    currency: "usd",

    recurring: false,
    interval: "month",
    cancellationMonths: 0,  // 0 або відсутнє → нормальна довгострокова підписка
    trialDays: 0
  },

  {
    id: "petro-003",
    clientName: "Петро",
    title: "Разова розробка лендингу",
    description:
      "Одноразова оплата за розробку лендингу: дизайн, верстка, базове SEO.",
    amountNet: 1200, // 800.00 USD
    currency: "usd",

    recurring: false // одноразовий платіж
    // interval / cancellationMonths / trialDays не потрібні
  }
];
